package GamePackage;
/*
 * Main class which is used to run and play game.
 */
public class Main extends Game {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Game game = new Game();
	game.play();
	}

}