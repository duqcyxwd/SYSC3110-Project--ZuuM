For Milestone 1, we were asked to implement the Zuul game with the following criterias:
-Still a text-based game
-have redo/undo commands
-multiple Items
-have an inventory
-have monsters in the game

We also had to show:
-UML diagrams (class and sequence diagrams)
-Our code of the game
-documentation
-readme file

To see the HTML JavaDoc go double click the index.html file and documentation for the whole
project will open in a browser.
In eclipse, the javaDoc plugin only allows us to see eather public, private, protected, package methods and members we just picked public. (it only shows variables and methods that are public and the constructors.)


The following milstone (2) asked us to have Units Test for the game, and have an implementation of the 2D view
-Our group is more than confident we are going to complete the milstone, we already started the unit tests
and our game is working perfectly fine (at the moment)

Their were no changes made to the previous Milstone since this is the first one

Authors and their role:

Bruno Colantonio: 
	-under/redo commands
	-cleaned up / fixed code
	-UML diagrams
	-readMe
	-documentation

Nishant Bhasin:
	-Monster in the game
	-cleaned up / fixed code
	-JavaDoc
	
Mohamed Ahmed:
	-undo/redo commands
	-items class
	-up/down commands
	-cleaned up / fixed code
	-documented

Yongquinchuan Du:
	-cleaned up / fixed code
	-started Unit test
	-initialized repoitory ()

undo/redo commands:
-for the undo redo commands we have created 3 stacks, one to keeps track of the rooms visited, one keeps track of all the commands, one keeps track of the undo commands.
-redo can only be called right after an undo, and since you push on to a stack when you undo, if you would not redo right after and do another command say go, then the stack of the 
undo commands are still there, to fix this whenever the command pick and go, if the undo command list is not empty we empty it.
-For further milstones we are going to look at ways to improve our redo/undo and try to reduce the number of stacks aswell, but not for it works perfectly.

Multiple Items / inventory:
-In the game we can have multiple Items which is stored in the inventory, each item has a description and a weight (for now) and later on in the game we will put use to these items.

Monsters:
-We can now have zero or multiple monsters per room, they dont do much yet, will have user interactions with the monster for milstone 2 (able to change rooms on its own, kill the monster etc.)

Also, things we can change, for commandWords and items we can enum instead of a whole class (we'll look more into it)